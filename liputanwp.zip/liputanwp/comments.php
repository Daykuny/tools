<?php 
if ( post_password_required() ) {
    return;
}
comment_form();
?>
<div id="comments" class="commentsArea">
<?php
if ( have_comments() ) :
?>
<h2 class="comments_title">
    <?php
        $comments_number = get_comments_number();
        if ( '1' === $comments_number ) {
            printf(
                _nx(
                '%1$s Komentar',
                '%1$s Komentar',
                $comments_number,
                'comments title'
            ),
            number_format_i18n( $comments_number ),
            get_the_title()
        );
        } else {
            printf(
                _nx(
                '%1$s Komentar',
                '%1$s Komentar',
                $comments_number,
                'comments title'
            ),
            number_format_i18n( $comments_number ),
            get_the_title()
        );
    }
    ?>
</h2>
<ol>
    <?php 
    wp_list_comments( array(
        'avatar_size' => 32,
        'short_ping'  => true,
        'walker'      => new Themes_Comment_Walker(),
    ));
    ?>
</ol>
<div class="comments-pagination">
<?php 
paginate_comments_links('prev_text=<svg width="10" height="12" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M-1-1h582v402H-1z"/><g><path d="M2.521 6.014l4.484 4.483a.306.306 0 0 0 .221.097.305.305 0 0 0 .222-.097l.48-.48a.305.305 0 0 0 0-.443l-3.78-3.782 3.78-3.781a.305.305 0 0 0 .097-.222.307.307 0 0 0-.096-.221l-.481-.481a.304.304 0 0 0-.443 0L2.52 5.57a.304.304 0 0 0 0 .443z" fill="currentColor" fill-rule="evenodd"/></g></svg>&next_text=<svg width="10" height="12" viewBox="0 0 10 12" xmlns="http://www.w3.org/2000/svg"><path d="M7.928 5.57L3.445 1.088a.306.306 0 0 0-.221-.096.305.305 0 0 0-.222.096l-.48.481a.305.305 0 0 0 0 .443l3.78 3.781-3.78 3.782a.305.305 0 0 0-.097.222c0 .083.032.156.096.221l.481.48a.304.304 0 0 0 .443 0l4.483-4.483a.304.304 0 0 0 0-.443z" fill="currentColor" fill-rule="evenodd"/></svg>'); ?>
</div>
<?php
endif;
    if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
    ?>
        <p class="no-comments"><?php _e( 'Comments are closed.'); ?></p>
    <?php
    endif;
?>
</div>