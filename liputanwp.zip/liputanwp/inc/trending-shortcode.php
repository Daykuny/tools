<?php 
add_shortcode( 'pospopuler', 'populer_shortcode' );
function populer_shortcode( $atts ) {
	global $post;
	$rentang = $atts["rentang"];
	$cat = $_GET['category'];
	$date = $_GET['date'];
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	if($cat == "" || $cat == "all"){
		$args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'meta_key' => 'post_views_count',
			'orderby'   => 'meta_value_num',
			'order' => 'DESC',
			'paged' => $paged,
			'date_query' => array(
				array(
					'after' => $rentang,
				),
			)
		);
	}else{
		$args = array(
			'category_name' => $cat,
			'post_type' => 'post',
			'post_status' => 'publish',
			'meta_key' => 'post_views_count',
			'orderby'   => 'meta_value_num',
			'order' => 'DESC',
			'paged' => $paged,
			'date_query' => array(
				array(
					'after' => $rentang,
				),
			)
		);
	}
	
	$konten = "";
	$no = 1;
	$my_trending = new WP_Query( $args );
	if ( $my_trending->have_posts() ):
		while ( $my_trending->have_posts() ) {
			$counter = get_post_meta( $post->ID, 'counter', true ); 
			$my_trending->the_post();
			$num = $no++;
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
				$konten .= '<div class="article-item table"><div class="article-text"><div class="article-time">';
				if(!empty(labelcategory())):
				$konten .= '<span class="article-category">' . labelcategory() . '</span>';
				endif;
				$konten .= timeago() . '</div><h2 class="article-title"><a href="' . get_permalink() . '" class="media-link">' . get_the_title() . '</a></h2></div><div class="article-image media-image">' . customthumbnail($post->ID, "thumbnail") . '';
				if(!empty($counter["foto"])):
				$konten .= '<div class="foto-counter"><?php echo $counter["foto"]; ?></div>';
				endif;
				if(!empty($counter["video"])):
				$konten .= '<div class="video-time"><?php echo $counter["video"]; ?></div>';
				endif;
				$konten .= '</div></div>';
			}else{
				$konten .= '<div class="article-item table"><div class="article-image media-image">' . customthumbnail($post->ID, "image_200_116") . '</div><div class="article-text"><div class="article-time">';
				if(!empty(labelcategory())):
				$konten .= '<span class="article-category">' . labelcategory() . '</span>';
				endif;
				$konten .= timeago() . '</div><h2 class="article-title"><a href="' . get_permalink() . '" class="media-link">' . get_the_title() . '</a></h2><div class="summary">' . get_excerpt(100) . '</div></div></div>';
			}
		}
		$konten .= '<div class="info"><button id="trigger1" class="trigger">Lihat Lainnya <i class="icon icon-arrow-right"></i></button>
		<div id="spinnerpost" class="loading"><div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div></div><div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div></div>';
        $total_pages = $my_trending->max_num_pages;
        if ($total_pages > 1){
			$konten .= '<div class="pagination">';
			$konten .= get_next_posts_link('"Lihat Lainnya', $my_trending->max_num_pages );
			$konten .= '</div>';
        }
	endif;
	wp_reset_postdata();
	return $konten;
}
?>