<?php 
require 'setup.php';
require 'lic.php';
require 'customizer.php';
require 'emoji.php';
require 'thumbnail.php';
require 'css.php';
require 'js.php';
require 'add-menu.php';
require 'section.php';
require 'brand.php';
require 'view.php';
require 'timeago.php';
require 'readtime.php';
require 'comment-threads.php';
require 'related-shortcode.php';
require 'trending-shortcode.php';
require 'terkini-shortcode.php';
require 'custom-post.php';
require 'lightbox.php';
require 'tgmpa/liputanwp.php';
require 'menu-image/menu-image-id.php';
?>