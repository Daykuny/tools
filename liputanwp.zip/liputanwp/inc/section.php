<?php 
function sidebar_menu() {
$args = array(
  'name'          => 'Menu Sidebar (Mobile)', 
  'id'            => 'sidebar_menu',
  'description'   => 'Menampilkan khusus widget menu navigasi',
  'before_widget' => '<div class="widget">',
  'after_widget'  => '</div>',
  'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
  'after_title'   => '</h3></div>',
);
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_menu' );


function parallax_mobile() {
    $args = array(
      'name'          => 'Iklan Parallax Mobile', 
      'id'            => 'parallax_mobile',
      'description'   => 'Menampilkan iklan parallax di mobile dengan ukuran gambar atau kode iklan (300x600) px',
      'before_widget' => '<div class="widget"><div class="widget-parallax">',
      'after_widget'  => '</div></div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'parallax_mobile' );

function parallax_desktop() {
    $args = array(
      'name'          => 'Iklan Parallax Desktop', 
      'id'            => 'parallax_desktop',
      'description'   => 'Menampilkan iklan parallax di desktop dengan ukuran gambar atau kode iklan (970x250) px',
      'before_widget' => '<div class="widget"><div class="widget-parallax">',
      'after_widget'  => '</div></div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'parallax_desktop' );

function billboard_area() {
    $args = array(
      'name'          => 'Iklan Billboard', 
      'id'            => 'billboard_area',
      'description'   => 'Menampilkan iklan billboard ukuran (970x250) px atau kode iklan iklan responsif',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'billboard_area' );

function breaking_area() {
    $args = array(
      'name'          => 'Breaking News', 
      'id'            => 'breaking_area',
      'description'   => 'Menampilkan widget khusus breaking',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'breaking_area' );

function homepage_area() {
    $args = array(
      'name'          => 'Beranda', 
      'id'            => 'homepage_area',
      'description'   => 'Menampilkan widget khusus dihalaman beranda.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'homepage_area' );

function afterpos_area() {
    $args = array(
      'name'          => 'Setelah Pos', 
      'id'            => 'afterpos_area',
      'description'   => 'Menampilkan widget di bagian bawah setelah artikel',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'afterpos_area' );

function sidebar_area() {
    $args = array(
      'name'          => 'Sidebar Beranda', 
      'id'            => 'sidebar_area',
      'description'   => 'Menampilkan widget di sidebar khusus halaman beranda.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_area' );

function sidebar_pos() {
    $args = array(
      'name'          => 'Sidebar Pos', 
      'id'            => 'sidebar_pos',
      'description'   => 'Menampilkan widget di sidebar khusus halaman pos',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_pos' );

function sidebar_archive() {
    $args = array(
      'name'          => 'Sidebar Arsip', 
      'id'            => 'sidebar_archive',
      'description'   => 'Menampilkan widget di sidebar khusus halaman arsip seperti halaman kategori, tag, pencarian, dan penulis',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_archive' );

function footer_left() {
    $args = array(
      'name'          => 'Footer Kiri', 
      'id'            => 'footer_left',
      'description'   => 'Menampilkan widget di dibagian footer kiri',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_left' );

function footer_right() {
    $args = array(
      'name'          => 'Footer Kanan', 
      'id'            => 'footer_right',
      'description'   => 'Menampilkan widget di dibagian footer kanan',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_right' );

function copyright() {
    $args = array(
      'name'          => 'Copyright', 
      'id'            => 'copyright',
      'description'   => 'Menampilkan widget teks berupa copyright dibagian bawah footer',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'copyright' );


function sticky_ads_left() {
    $args = array(
      'name'          => 'Iklan Melayang Bagian Kiri', 
      'id'            => 'sticky_ads_left',
      'description'   => 'Menampilkan iklan gambar atau kode iklan (160x600) px dan hanya ditampilkan di desktop',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_left' );

function sticky_ads_right() {
    $args = array(
      'name'          => 'Iklan Melayang Bagian Kanan', 
      'id'            => 'sticky_ads_right',
      'description'   => 'Menampilkan iklan gambar atau kode iklan (160x600) px dan hanya ditampilkan di desktop',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h3 class="widget-title">',
      'after_title'   => '</h3></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_right' );
?>