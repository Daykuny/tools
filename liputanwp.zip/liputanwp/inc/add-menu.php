<?php 
function desktop_menu(){
  $args = array(
    'theme_location'  => 'desktop_menu', 
    'menu'            => 'Menu Utama (Desktop)', 
    'container'       => 'nav', 
    'container_class' => '', 
    'container_id'    => '', 
    'menu_class'      => 'widget LinkList', 
    'menu_id'         => '', 
    'echo'            => true, 
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '', 
    'after'           => '', 
    'link_before'     => '', 
    'link_after'      => '', 
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>', 
    'depth'           => 0,
    'walker'          => '', 
  );
  wp_nav_menu($args);
}
function mobile_menu(){
  $args = array(
    'theme_location'  => 'mobile_menu', 
    'menu'            => 'Menu Utama (Mobile)', 
    'container'       => 'nav', 
    'container_class' => '', 
    'container_id'    => '', 
    'menu_class'      => 'widget LinkList', 
    'menu_id'         => '', 
    'echo'            => true, 
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '', 
    'after'           => '', 
    'link_before'     => '', 
    'link_after'      => '', 
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>', 
    'depth'           => 0,
    'walker'          => '', 
  );
  wp_nav_menu($args);
}
$register_menu = array(
    'desktop_menu' => 'Menu Utama (Desktop)',
    'mobile_menu' => 'Menu Utama (Mobile)',
);
register_nav_menus($register_menu);

?>