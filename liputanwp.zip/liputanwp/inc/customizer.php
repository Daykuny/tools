<?php 

function addCustomize($wp_customize) {
	$wp_customize->add_panel( 'ThemesappPos', array(
	  'title' => 'Themesapp',
	  'priority' => 162,
	));

		// Warna =========================================================== 
		$wp_customize->add_section( 'color', array(
	    	'title' => 'Warna Situs',
		  	'description'=> 'Atur warna situs sesuai dengan keinginan.',
			'panel' => 'ThemesappPos',
	    ));
	    $wp_customize->add_setting( 'primary' , array(
	        'default'     => "#ff3000",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'primary', array(
	        'label'        => 'Warna Utama',
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'secondary' , array(
	        'default'     => "#e85804",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'secondary', array(
	        'label'        => 'Warna Kedua',
	        'section'    => 'color',
	    )));

		
		
		/* UNGGULAN */
		$wp_customize->add_section( 'featuredimage' , array(
	      'title' => 'Gambar Unggulan',
		  'panel' => 'ThemesappPos',
		  'description'=> 'Atur tampilan gambar unggulan disini',
		));
		$wp_customize->add_setting( 'featuredimageactivepos' , array(
			'default'    => false,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('featuredimageactivepos' , array(
			'section' => 'featuredimage',
			'label' => 'Tampilkan gambar unggulan di halaman post',
			'type'=>'checkbox',
		));


		/* REDAKSI */
		$wp_customize->add_section( 'timredaksi' , array(
		  'title'      => 'Tim Redaksi',     
		  'panel' => 'ThemesappPos',
		  'description'=> 'Atur tampilan untuk tim redaksi disini',
		));

		$wp_customize->add_setting( 'timredaksiactive' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksiactive' , array(
			'label' => 'Tampilkan tim redaksi',
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'tombolredaksititle' , array(
			'default'    => 'Tim Redaksi',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolredaksititle' , array(
			'section' => 'timredaksi',
			'label' =>'Judul',
			'type'=>'text',
		));
		$wp_customize->add_setting( 'timredaksipenulis' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksipenulis' , array(
			'label' => 'Tampilkan penulis',
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'timredaksieditor' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksieditor' , array(
			'label' => 'Tampilkan editor',
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'timredaksireporter' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksireporter' , array(
			'label' => 'Tampilkan reporter',
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));

			
		/* SHARE */
		$wp_customize->add_section( 'tombolbagikan' , array(
		  'title'      => 'Tombol Bagikan',     
		  'panel' => 'ThemesappPos',
		  'description'=> 'Berikut ini adalah pengaturan tampilan untuk popup tombol share. Disini kamu bisa mengatur tombol mana yang ingin kamu aktifkan',
		));
		$wp_customize->add_setting( 'tombolsharetitle' , array(
			'default'    => 'Bagikan',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolsharetitle' , array(
			'section' => 'tombolbagikan',
			'label' =>'Judul Tombol',
			'type'=>'text',
		));
		$wp_customize->add_setting( 'tombolwhatsapp' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolwhatsapp' , array(
			'label' => 'Whatsapp',
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'tombolfacebook' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfacebook' , array(
			'label' => 'Facebook',
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'tomboltwitter' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tomboltwitter' , array(
			'label' => 'Twitter',
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'tombolemail' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolemail' , array(
			'label' => 'Email',
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'tombolcopylink' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolcopylink' , array(
			'label' => 'Copylink',
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));

		/* ads parallax */
		$wp_customize->add_section( 'parallax' , array(
		  'title'      => 'Iklan Parallax',     
		  'panel' => 'ThemesappPos',
		  'description'=> 'Atur tampilan iklan parallax disini',
		));
		$wp_customize->add_setting( 'widthparallaxmobile' , array(
			'default'    => '300px',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('widthparallaxmobile' , array(
			'section' => 'parallax',
			'label' =>'Lebar Iklan Versi Mobile',
			'type'=>'text',
		));
		$wp_customize->add_setting( 'heightparallaxmobile' , array(
			'default'    => '600px',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('heightparallaxmobile' , array(
			'section' => 'parallax',
			'label' =>'Tinggi Iklan Versi Mobile',
			'type'=>'text',
		));
		$wp_customize->add_setting( 'widthparallaxdesktop' , array(
			'default'    => '100%',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('widthparallaxdesktop' , array(
			'section' => 'parallax',
			'label' =>'Lebar Iklan Versi Desktop',
			'type'=>'text',
		));
		$wp_customize->add_setting( 'heightparallaxdesktop' , array(
			'default'    => '250px',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('heightparallaxdesktop' , array(
			'section' => 'parallax',
			'label' =>'Tinggi Iklan Versi Desktop',
			'type'=>'text',
		));
		
		$wp_customize->add_section( 'licPost' , array(
		  'title'      => 'Lisensi',     
		  'description'=> '',
		  'panel' => 'ThemesappPos',
		));

		$wp_customize->add_setting( 'lic' , array(
			'default'    => '',
			'transport'  =>  'postMessage'
		));
		$wp_customize->add_control('lic' , array(
			'section' => 'licPost',
			'label' =>'Lisensi Tema',
			'type'=>'text',
			'input_attrs' => array(
            'placeholder' => __( 'Masukan lisensi tema disini'),
        )
		));
			

}
add_action( 'customize_register', 'addCustomize' );

?>