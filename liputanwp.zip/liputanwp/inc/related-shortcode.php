<?php 
add_shortcode( 'related', 'related_shortcode' );
function related_shortcode( $atts ) {
	global $post;
	$berdasarkan = $atts["by"];
	$jml = $atts["number"];
	$title = $atts["title"];
	if($berdasarkan == "category"){
	    $categories = get_the_category( $post->ID );
	    $categorieIDs = array();
		if ( $categories ) {
			$categoriecount = count( $categories );
	        for ( $i = 0; $i < $categoriecount; $i++ ) {
	            $categorieIDs[$i] = $categories[$i]->term_id;
	        }
	        $args = array(
	            'category__in' => $categorieIDs,
				'post_type' => 'post',
				'post_status' => 'publish',
      			'offset' => $start,
	            'post__not_in' => array( $post->ID ),
	            'posts_per_page'=> $jml
	        );
	    }
	} else if($berdasarkan == "tag"){
	    $tags = wp_get_post_tags( $post->ID );
	    $tagIDs = array();

		if ( $tags ) {
			$tagcount = count( $tags );
	        for ( $i = 0; $i < $tagcount; $i++ ) {
	            $tagIDs[$i] = $tags[$i]->term_id;
	        }
	        $args = array(
	            'tag__in' => $tagIDs,
				'post_type' => 'post',
				'post_status' => 'publish',
      			'offset' => $start,
	            'post__not_in' => array( $post->ID ),
	            'posts_per_page'=> $jml
	        );
	    }
	}else{
	    $args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
      		'offset' => $start,
	        'post__not_in' => array( $post->ID ),
	        'posts_per_page'=> $jml
	    );

	}
    if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
    }else{
	$konten = "";
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
	    $konten .= '<div class="bacajuga">';
	    if(!empty($title)):
	    $konten .= '<h3>' . $title . '</h3>';
	    endif;
	    $konten .= '<div class="bacajuga-wrapper">';
			while ($my_query->have_posts()) {
				$my_query->the_post();
				$konten .= '<div class="bacajuga-item"><a href="' . get_permalink() . '">' . get_the_title() . '</a></div>';
			}
	    $konten .= '</div></div>';
	wp_reset_postdata();
	endif;
	return $konten;
}
}
?>