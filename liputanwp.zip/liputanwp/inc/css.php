<?php 
function addcss() { 
  $versi = '2.0.02';
  wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/css/normalize.css', '', $versi );
  wp_enqueue_style( 'font', get_template_directory_uri() . '/assets/css/font.css', '', $versi );
  if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
    wp_enqueue_style( 'cssmobile', get_template_directory_uri() . '/assets/css/style-amp.css', '', $versi );
	}elseif(wp_is_mobile()) {
      if(is_page_template('indeks.php')) :
        wp_enqueue_style( 'daterange', get_template_directory_uri() . '/assets/css/pikaday.css', '', $versi );
      endif;
    wp_enqueue_style( 'slick', get_template_directory_uri() . '/assets/css/slick.min.css', $versi );
    wp_enqueue_style( 'cssmobile', get_template_directory_uri() . '/assets/css/style-mobile.css', '', $versi );
  }else {
      if(is_page_template('indeks.php')) :
        wp_enqueue_style( 'daterange', get_template_directory_uri() . '/assets/css/pikaday.css', '', $versi );
      endif;
    wp_enqueue_style( 'slick', get_template_directory_uri() . '/assets/css/slick.min.css', $versi );
    wp_enqueue_style( 'cssdesktop', get_template_directory_uri() . '/assets/css/style-desktop.css', '', $versi );
  }
}
add_action( 'wp_enqueue_scripts', 'addcss' );

function addattrcss( $html, $handle ) {
    if ('cssmobile' === $handle 
        || 'normalize' === $handle 
        || 'dashicons' === $handle 
        || 'icon' === $handle 
        || 'admin-bar' === $handle 
        || 'wp-block-library' === $handle 
        || 'menu-image' === $handle 
        || 'cssdesktop' === $handle 
    ) :
        return str_replace( "media='all'", "media='all' async='async'", $html );
    endif;
    return $html;
}
add_filter( 'style_loader_tag', 'addattrcss', 10, 2 );

add_action( 'admin_enqueue_scripts', 'load_admin_styles' );
function load_admin_styles() {
    $versi = '1.0.0';
    wp_enqueue_style( 'admin_css_foo', get_template_directory_uri() . '/assets/css/admin.css', false, $versi );
}
function customcss()
{
?>
<style type="text/css" id="custom-theme-css">
:root {
<?php if(!empty(get_theme_mod( 'primary' ))):?>
  --primary: <?php echo get_theme_mod( 'primary' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'secondary' ))):?>
  --secondary: <?php echo get_theme_mod( 'secondary' ); ?>;
<?php endif; ?>

<?php if(!empty(get_theme_mod( 'widthparallaxmobile' ))):?>
  --widthparallaxmobile: <?php echo get_theme_mod( 'widthparallaxmobile' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'heightparallaxmobile' ))):?>
  --heightparallaxmobile: <?php echo get_theme_mod( 'heightparallaxmobile' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'widthparallaxdesktop' ))):?>
  --widthparallaxdesktop: <?php echo get_theme_mod( 'widthparallaxdesktop' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'heightparallaxdesktop' ))):?>
  --heightparallaxdesktop: <?php echo get_theme_mod( 'heightparallaxdesktop' ); ?>;
<?php endif; ?>

}
</style>
<?php
}
add_action( 'wp_head', 'customcss');