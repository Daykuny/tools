<?php
function breakingViewDesktop($judul,$category, $jml){
	global $post;
	if(is_single()):
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'post__not_in' => array( $post->ID ),
		'posts_per_page'=> $jml
	);
	else:
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	endif;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
					
		<div class="breaking">
			<div class="breaking-container">
				<?php if(!empty($judul)): ?>
					<span class="breaking-title"><?php echo $judul; ?></span>
				<?php endif; ?>
				<marquee class="breaking-content">
				<?php while ( $my_query->have_posts() ) {
				$my_query->the_post();?>
						<a href="<?php echo get_permalink(); ?>">
							<span class="breaking-link"><?php echo get_the_title(); ?></span>
						</a>
				<?php 
				}?>
				</marquee>
			</div>
		</div>
	<?php	
	endif;
	wp_reset_postdata();
}
function breakingViewMobile($judul,$category, $jml){
	global $post;
	if(is_single()):
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'post__not_in' => array( $post->ID ),
		'posts_per_page'=> $jml
	);
	else:
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	endif;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
					
		<div class="breaking">
			<div class="breaking-container">
				<?php if(!empty($judul)): ?>
					<span class="breaking-title"><?php echo $judul; ?></span>
				<?php endif; ?>
				<marquee class="breaking-content">
				<?php while ( $my_query->have_posts() ) {
				$my_query->the_post();?>
						<a href="<?php echo get_permalink(); ?>">
							<span class="breaking-link"><?php echo get_the_title(); ?></span>
						</a>
				<?php 
				}?>
				</marquee>
			</div>
		</div>
	<?php	
	endif;
	wp_reset_postdata();
}
class breakingWidget extends WP_Widget {

    public function __construct() {
        $idwidget = 'breaking';
        $namewidget = '✅ Breaking';
        $descwidget = 'Widget ini menampilan daftar pos berdasarkan kategori yang dipilih dan ditampilkan dalam bentuk widget breaking';
        parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
    }
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				breakingViewMobile($instance['title'], $instance['category'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				breakingViewMobile($instance['title'], $instance['category'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				breakingViewDesktop($instance['title'], $instance['category'],$instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['category'] = $new_instance['category'];
        $instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
        $instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
	    $defaults = array(
	        'title' => '',
			'category' => '',
			'amountdesktop' => '1',
			'amountmobile' => '1',
	        'desktop' => 'yes',
	        'mobile' => 'yes',
	    );
	    $instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
		    <hr>
			<p class="datacat">
				<label for="<?php echo $this->get_field_id( 'category' ); ?>">Kategori</label>
				<div class="over">
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
						if(!empty($instance['category'])):
							$ch = in_array( $term->term_id, $instance['category']) ? 'checked="checked"' : '';
						else:
							$ch = "";
						endif;
					?>
					<div class="over-flex">
						<input type="checkbox" id="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>" name="<?php echo $this->get_field_name( 'category' ); ?>[]" value="<?php echo $term->term_id; ?>" <?php echo $ch; ?>>
						<label for="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>"><?php echo $term->name; ?></label>
					</div>
					<?php } ?>
				</div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>">Jumlah pos versi desktop</label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>">Jumlah pos versi mobile</label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
		    <hr>
		    <p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
		    </p>
		</div>
		<?php
	}
}

function breakingWidgetload() {
    register_widget( 'breakingWidget' );
}
add_action( 'widgets_init', 'breakingWidgetload' );