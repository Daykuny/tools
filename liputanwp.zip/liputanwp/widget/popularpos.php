<?php
function popularposViewDesktop($judul,$category,$rentang,$jml){
	global $post;
	if(is_single()):
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
	    'post_status' => 'publish',
		'post__not_in' => array( $post->ID ),
		'meta_key' => 'post_views_count',
		'orderby'   => 'meta_value_num',
		'posts_per_page'=> $jml,
		'order' => 'DESC',
		'date_query' => array(
			array(
				'after' => $rentang,
			),
		)
	);
	else:
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
	    'post_status' => 'publish',
		'meta_key' => 'post_views_count',
		'orderby'   => 'meta_value_num',
		'posts_per_page'=> $jml,
		'order' => 'DESC',
		'date_query' => array(
			array(
				'after' => $rentang,
			),
		)
	);
	endif;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		?>
			<div class="widget popularpos">
				<?php if(!empty($judul)): ?>
				<div class="widget-header">
					<h3 class="widget-title"><?php echo $judul; ?></h3>
				</div>
				<?php endif; ?>
				<div class="widget-content">
						<?php
						$no = 1;
						while ( $my_query->have_posts() ) {
							$my_query->the_post();
							$nomor = $no++;
							if($nomor == 1){
							?>
								<div class="popularpos-item">
									<div class="popularpos-image media-image">
										<?php echo customthumbnail($post->ID, "image_300_168"); ?>
									</div>
									<div class="popularpos-content">
										<span class="popularpos-number"><?php echo $nomor; ?></span>
										<div class="popularpos-text">
											<?php if(!empty(labelcategory())): ?>
												<span class="popularpos-category"><?php echo labelcategory(); ?></span>
											<?php endif; ?>
											<h2 class="popularpos-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
									</div>
								</div>
							<?php
							}else{
							?>
								<div class="popularpos-item">
									<div class="popularpos-content">
										<span class="popularpos-number"><?php echo $nomor; ?></span>
										<div class="popularpos-text">
											<?php if(!empty(labelcategory())): ?>
												<span class="popularpos-category"><?php echo labelcategory(); ?></span>
											<?php endif; ?>
											<h2 class="popularpos-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
									</div>
								</div>
							<?php
							}
						?>
						<?php
						}
						?>
				</div>
			</div>
		<?php 
	endif;
	wp_reset_postdata();
}
function popularposViewMobile($judul,$category,$rentang,$jml){
	global $post;
	if(is_single()):
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
	    'post_status' => 'publish',
		'post__not_in' => array( $post->ID ),
		'meta_key' => 'post_views_count',
		'orderby'   => 'meta_value_num',
		'posts_per_page'=> $jml,
		'order' => 'DESC',
		'date_query' => array(
			array(
				'after' => $rentang,
			),
		)
	);
	else:
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
	    'post_status' => 'publish',
		'meta_key' => 'post_views_count',
		'orderby'   => 'meta_value_num',
		'posts_per_page'=> $jml,
		'order' => 'DESC',
		'date_query' => array(
			array(
				'after' => $rentang,
			),
		)
	);
	endif;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		?>
			<div class="widget popularpos">
				<?php if(!empty($judul)): ?>
				<div class="widget-header">
					<h3 class="widget-title"><?php echo $judul; ?></h2>
				</div>
				<?php endif; ?>
				<div class="widget-content">
						<?php
						$no = 1;
						while ( $my_query->have_posts() ) {
							$my_query->the_post(); 
							$nomor = $no++;?>
								<div class="popularpos-item">
									<div class="popularpos-content">
										<span class="popularpos-number"><?php echo $nomor; ?></span>
										<div class="popularpos-text">
											<?php if(!empty(labelcategory())): ?>
												<span class="popularpos-category"><?php echo labelcategory(); ?></span>
											<?php endif; ?>
											<h2 class="popularpos-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
									</div>
								</div>
						<?php
						}
						?>
				</div>
			</div>
		<?php 
	endif;
	wp_reset_postdata();
}
class popularposWidget extends WP_Widget {

	public function __construct() {
		$idwidget = 'popularpos';
		$namewidget = '✅ Pos Terpopuler';
		$descwidget = 'Menampilan daftar pos terpopuler berdasarkan rentang tertentu';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				popularposViewMobile($instance['title'], $instance['category'], $instance['rentang'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				popularposViewMobile($instance['title'], $instance['category'], $instance['rentang'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				popularposViewDesktop($instance['title'], $instance['category'], $instance['rentang'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		$instance['category'] = $new_instance['category'];
		if ( ! empty( $new_instance['rentang'] ) ) {
			$instance['rentang'] = sanitize_text_field( $new_instance['rentang'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'category' => '',
			'rentang' => '-1',
			'amountdesktop' => '10',
			'amountmobile' => '10',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<p class="datacat">
				<label for="<?php echo $this->get_field_id( 'category' ); ?>">Kategori</label>
				<div class="over">
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
						if(!empty($instance['category'])):
							$ch = in_array( $term->term_id, $instance['category']) ? 'checked="checked"' : '';
						else:
							$ch = "";
						endif;
					?>
					<div class="over-flex">
						<input type="checkbox" id="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>" name="<?php echo $this->get_field_name( 'category' ); ?>[]" value="<?php echo $term->term_id; ?>" <?php echo $ch; ?>>
						<label for="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>"><?php echo $term->name; ?></label>
					</div>
					<?php } ?>
				</div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'rentang' ); ?>">Rentang waktu pos</label>
				<select id="<?php echo $this->get_field_id('rentang'); ?>" name="<?php echo $this->get_field_name('rentang'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['rentang'], '10 years ago' ); ?> value="10 years ago">-- Pilih --</option>
					<option <?php selected( $instance['rentang'], '1 day ago' ); ?> value="1 day ago">1 Hari</option>
					<option <?php selected( $instance['rentang'], '7 day ago' ); ?> value="7 day ago">7 Hari</option>
					<option <?php selected( $instance['rentang'], '1 month ago' ); ?> value="1 month ago">1 Bulan</option>
					<option <?php selected( $instance['rentang'], '1 years ago' ); ?> value="1 years ago">1 Tahun</option>
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>">Jumlah pos versi desktop</label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>">Jumlah pos versi mobile</label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function popularposWidgetload() {
	register_widget( 'popularposWidget' );
}
add_action( 'widgets_init', 'popularposWidgetload' );