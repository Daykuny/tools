<?php
function headlineViewDesktop($subtitle,$category,$jml){
	global $post;
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget headline">
			<?php
			$no = 1;
			$headline = "";
			if(!empty($subtitle)):
			$before = '<div class="slider-inline"> <div class="widget-header"> <h3 class="widget-title">' . $subtitle . '</h3> </div> <div class="widget-content"> <div class="viewport"> <div class="overview table">';
			else:
			$before = '<div class="slider-inline"><div class="widget-content"> <div class="viewport"> <div class="overview table">';
			endif;
			$slider = "";
			while ( $my_query->have_posts() ) {
				$my_query->the_post();
					$nomor = $no++;
					if($nomor > 1){
						$slider .= '<div class="slider-item">
						<div class="slider-image media-image">'. customthumbnail($post->ID, "image_200_116") .'</div>
						<div class="slider-text">
							<div class="slider-time">';
						if ( has_post_format(array('image', 'gallery'))):
						$slider .= '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><path d="M2 5.413h3.547L6.946 2h7.832l1.4 3.413h3.546v11.82H2z"/><path stroke="currentColor" d="M10.862 7.378a2.795 2.795 0 0 1 2.788 2.8 2.795 2.795 0 0 1-2.788 2.802 2.795 2.795 0 0 1-2.788-2.801 2.795 2.795 0 0 1 2.788-2.801zm0-1.965c2.62 0 4.744 2.134 4.744 4.766 0 2.631-2.124 4.765-4.744 4.765-2.62 0-4.744-2.134-4.744-4.765 0-2.632 2.124-4.766 4.744-4.766z"/><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M2 5.413h3.547L6.946 2h7.832l1.4 3.413h3.546v11.82H2z"/></g></svg>';
						elseif ( has_post_format('video') ):
						$slider .= '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><path fill="currentColor" d="M8.262 15.526a.368.368 0 0 1-.369-.368v-8.35a.368.368 0 0 1 .553-.319l7.23 4.175a.368.368 0 0 1 0 .638l-7.23 4.174a.368.368 0 0 1-.184.05zm.368-8.08v7.074l6.126-3.537L8.63 7.446z"/><path fill="currentColor" d="M10.983 19.966c-2.4 0-4.655-.935-6.352-2.631A8.924 8.924 0 0 1 2 10.983c0-2.4.934-4.655 2.631-6.352A8.924 8.924 0 0 1 10.983 2c2.4 0 4.655.934 6.352 2.631a8.924 8.924 0 0 1 2.63 6.352c0 2.4-.934 4.655-2.63 6.352a8.924 8.924 0 0 1-6.352 2.63zm0-17.23a8.193 8.193 0 0 0-5.831 2.416 8.193 8.193 0 0 0-2.416 5.831 8.19 8.19 0 0 0 2.416 5.831 8.193 8.193 0 0 0 5.83 2.416 8.193 8.193 0 0 0 5.832-2.416 8.193 8.193 0 0 0 2.416-5.831 8.193 8.193 0 0 0-2.416-5.831 8.193 8.193 0 0 0-5.831-2.416z"/><path d="M0 0h22v22H0z"/></g></svg>';
						endif;
						$slider .= timeago() . '</div>
								<h2 class="slider-title">
									<a href="' . get_permalink() . '" class="media-link">' . get_the_title() . '</a>
								</h2>
							</div>
						</div>';
					}else{
						$headline .= '<div class="headline-big">
							<div class="headline-box">
								<div class="headline-image media-image">'. customthumbnail($post->ID, "image_640_360") .'</div>
								<div class="headline-text">
									<div class="headline-time">';
									if ( has_post_format(array('image', 'gallery'))):
									$headline .= '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><path d="M2 5.413h3.547L6.946 2h7.832l1.4 3.413h3.546v11.82H2z"/><path stroke="currentColor" d="M10.862 7.378a2.795 2.795 0 0 1 2.788 2.8 2.795 2.795 0 0 1-2.788 2.802 2.795 2.795 0 0 1-2.788-2.801 2.795 2.795 0 0 1 2.788-2.801zm0-1.965c2.62 0 4.744 2.134 4.744 4.766 0 2.631-2.124 4.765-4.744 4.765-2.62 0-4.744-2.134-4.744-4.765 0-2.632 2.124-4.766 4.744-4.766z"/><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M2 5.413h3.547L6.946 2h7.832l1.4 3.413h3.546v11.82H2z"/></g></svg>';
									elseif ( has_post_format('video') ):
									$headline .= '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><path fill="currentColor" d="M8.262 15.526a.368.368 0 0 1-.369-.368v-8.35a.368.368 0 0 1 .553-.319l7.23 4.175a.368.368 0 0 1 0 .638l-7.23 4.174a.368.368 0 0 1-.184.05zm.368-8.08v7.074l6.126-3.537L8.63 7.446z"/><path fill="currentColor" d="M10.983 19.966c-2.4 0-4.655-.935-6.352-2.631A8.924 8.924 0 0 1 2 10.983c0-2.4.934-4.655 2.631-6.352A8.924 8.924 0 0 1 10.983 2c2.4 0 4.655.934 6.352 2.631a8.924 8.924 0 0 1 2.63 6.352c0 2.4-.934 4.655-2.63 6.352a8.924 8.924 0 0 1-6.352 2.63zm0-17.23a8.193 8.193 0 0 0-5.831 2.416 8.193 8.193 0 0 0-2.416 5.831 8.19 8.19 0 0 0 2.416 5.831 8.193 8.193 0 0 0 5.83 2.416 8.193 8.193 0 0 0 5.832-2.416 8.193 8.193 0 0 0 2.416-5.831 8.193 8.193 0 0 0-2.416-5.831 8.193 8.193 0 0 0-5.831-2.416z"/><path d="M0 0h22v22H0z"/></g></svg>';
									endif;
									$headline .= timeago() . '</div>
										<h2 class="headline-title">
											<a href="' . get_permalink() . '" class="media-link">' . get_the_title() . '</a>
										</h2>
										<div class="headline-content">' . get_excerpt(150) . '</div>
									</div>
								</div>
							</div>';
					}
				?>
				<?php
			}
			wp_reset_postdata();

			$after = '</div> </div>  </div> </div>'; 
			if($nomor > 1){
			echo $headline . $before . $slider . $after;
			}else{
			echo $headline;
			}
			?>
		</div>
		<?php
	endif;
}
function headlineViewMobile($category,$jml){
	global $post;
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'post__not_in' => array( $post->ID ),
		'posts_per_page'=> $jml
	);
	global $post;
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget headline">
			<?php
			$no = 1;
			$headline = "";
			while ( $my_query->have_posts() ) {
				$my_query->the_post();
					$nomor = $no++;
					if($nomor > 1){
					}else{
						$headline .= '<div class="headline-big">
							<div class="headline-box">
								<div class="headline-image media-image">'. customthumbnail($post->ID, "image_640_360") .'</div>
								<div class="headline-text">
									<div class="headline-time">';
									$headline .= timeago() . '</div>
										<h2 class="headline-title">
											<a href="' . get_permalink() . '" class="media-link">' . get_the_title() . '</a>
										</h2>
									</div>
								</div>
							</div>';
					}
				?>
				<?php
			}
			wp_reset_postdata();
			echo $headline;
			?>
		</div>
		<?php
	endif;
}
class headlineHome extends WP_Widget {

	public function __construct() {
		$idwidget = 'headlinehome';
		$namewidget = '✅ Headline';
		$descwidget = 'Menampilan daftar pos headline tertentu';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				headlineViewMobile($instance['category'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				headlineViewMobile($instance['category'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				headlineViewDesktop($instance['subtitle'], $instance['category'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['subtitle'] ) ) {
			$instance['subtitle'] = sanitize_text_field( $new_instance['subtitle'] );
		}
		$instance['category'] = $new_instance['category'];
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'subtitle' => '',
			'category' => '',
			'amountdesktop' => '4',
			'amountmobile' => '1',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'subtitle' ); ?>">Sub Judul</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'subtitle' ); ?>" name="<?php echo $this->get_field_name( 'subtitle' ); ?>" value="<?php echo $instance['subtitle']; ?>" />
			</p>
			<p class="datacat">
				<label for="<?php echo $this->get_field_id( 'category' ); ?>">Kategori</label>
				<div class="over">
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
						if(!empty($instance['category'])):
							$ch = in_array( $term->term_id, $instance['category']) ? 'checked="checked"' : '';
						else:
							$ch = "";
						endif;
					?>
					<div class="over-flex">
						<input type="checkbox" id="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>" name="<?php echo $this->get_field_name( 'category' ); ?>[]" value="<?php echo $term->term_id; ?>" <?php echo $ch; ?>>
						<label for="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>"><?php echo $term->name; ?></label>
					</div>
					<?php } ?>
				</div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>">Jumlah pos versi desktop</label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>">Jumlah pos versi mobile</label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function headlineHomeload() {
	register_widget( 'headlineHome' );
}
add_action( 'widgets_init', 'headlineHomeload' );