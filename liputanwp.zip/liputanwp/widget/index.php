<?php 
require 'popularpos.php';
require 'populartag.php';
require 'list.php';
require 'headline.php';
require 'slider.php';
require 'breaking.php';
require 'related.php';
?>