<?php if(!empty(get_the_author_meta('description'))): ?>
	<div class="author-bio"><?php echo get_the_author_meta('description'); ?></div>
<?php endif; ?>