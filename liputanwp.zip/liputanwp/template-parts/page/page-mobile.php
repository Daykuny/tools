<div class="main">
	<div class="main-container">
		<div class="article-row">
		<div class="article">
			<div class="article-wrapper">
				<div class="article-box">
					<?php 
					if (have_posts()):
					while (have_posts()): the_post();
					$tim = get_post_meta(get_the_ID(), 'tim', true );
					?>
					<div class="post-detail">
					    <div class="post">
					    	<div class="post-header">
					    		<h1 class="post-title"><?php the_title(); ?></h1>
					    	</div>
					    	<div class="post-content">
					    		<?php the_content(); ?>
					    	</div>
					    </div>
					</div>
				<?php
				endwhile;
				endif; ?>
				</div>
			</div>
		</div>
		</div>
	</div>
</div>