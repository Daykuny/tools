<?php 
if (have_posts()):
while (have_posts()): the_post(); 
	$counter = get_post_meta( $post->ID, 'counter', true );?>
	<div class="article-item table">
		<div class="article-text">
			<div class="article-time">
				<?php if(!empty(labelcategory())): ?>
					<span class="article-category"><?php echo labelcategory(); ?></span>
				<?php endif; ?>
				<?php echo timeago(); ?>
			</div>
			<h2 class="article-title">
				<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
			</h2>
		</div>
		<div class="article-image media-image">
			<?php echo customthumbnail($post->ID, "thumbnail"); ?>
			<?php if(!empty($counter["foto"])): ?>
			<div class="foto-counter"><?php echo $counter["foto"]; ?></div>
			<?php endif; ?>
			<?php if(!empty($counter["video"])): ?>
			<div class="video-time"><?php echo $counter["video"]; ?></div>
			<?php endif; ?>
		</div>
	</div>
<?php endwhile; ?>

<div class="info">
	<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
	<div id="spinnerpost" class="loading">
		<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
	</div>
	<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
</div>
<div class="pagination">
	<?php echo get_next_posts_link("Lihat Lainnya <i class='icon icon-arrow-right'></i>"); ?>
</div>
<?php endif; ?>