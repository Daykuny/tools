<div class="main">
	<div class="main-container">
		<div class="article-row">
				<?php $class = "";
				$cat = $_GET['category'];
				$date = $_GET['date'];
				?>
			<div class="sidebar kanal-box">
				<div class="kanal-menu">
					<div class="kanal-header">
						<div class="kanal-title">Kategori</div>
					</div>
					<div class="kanal-body">
						<ul>
							<li class="<?php if ($cat == "" || $cat == "all"){echo "current-menu-item";}?>"><a href="?category=all">Semua Kategori <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg></a></li>
						<?php foreach(get_terms('category','parent=0&hide_empty=true') as $term) { ?>
							<li class="<?php if ($cat==$term->slug){echo "current-menu-item";}?>"><a href="?category=<?php echo $term->slug; ?>"><?php echo $term->name; ?> <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg></a></li>
						<?php } ?>
						</ul>
					</div>
				</div>
			</div>
			<div class="article kanal-box">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="indeks-data">
							<div id="boxDate">
								<input type="text" class="form-control" id="startDate" value="<?php echo $date; ?>" placeholder="Tanggal" disabled>
							</div>
							<div class="btn-form-indeks">Lihat</div>
						</div>
						<h1 class="indeks-title"><?php the_title(); ?></h1>
						<div class="latest-area" data-indeks="<?php echo get_permalink(); ?>">
						<?php 
						$cat = $_GET['category'];
						$date = $_GET['date'];
						$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
						if($cat == "" && $date == "" || $cat == "all" && $date == ""){
							$args = array(
								'post_type' => 'post',
								'post_status' => 'publish',
								'paged' => $paged
							);
						}else if($cat != "" && $date == ""){
							$args = array(
								'category_name' => $cat,
								'post_type' => 'post',
								'post_status' => 'publish',
								'paged' => $paged
							);

						}else if($cat != "" && $date != ""){
							$timestart = strtotime($date);
							$timeend = strtotime($date . ' + 1 days');
							$start = date('d-m-Y',$timestart);
							$end = date('d-m-Y',$timeend);
							if($cat == "all"){
								$args = array(
									'post_type' => 'post',
									'post_status' => 'publish',
									'paged' => $paged,
									'date_query' => array(
										array(
						                    'after'     => $start,
						                    'before'    => $end,
										),
									),
								);
							}else{
								$args = array(
									'category_name' => $cat,
									'post_type' => 'post',
									'post_status' => 'publish',
									'paged' => $paged,
									'date_query' => array(
										array(
						                    'after'     => $start,
						                    'before'    => $end,
										),
									),
								);
							}
						}?>
						<?php 
						$my_query = new WP_Query( $args );
						if ( $my_query->have_posts() ):
							while ( $my_query->have_posts() ) :
								$my_query->the_post(); 
			                    $counter = get_post_meta( get_the_ID(), 'counter', true );?>
								<div class="article-item table">
									<div class="article-image media-image">
										<?php echo customthumbnail($post->ID, "image_200_116"); ?>
									</div>
									<div class="article-text">
										<div class="article-time">
											<?php if(!empty(labelcategory())): ?>
												<span class="article-category"><?php echo labelcategory(); ?></span>
											<?php endif; ?>
											<?php echo timeago(); ?>
										</div>
										<h2 class="article-title">
											<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
										</h2>
										<div class="summary"><?php echo get_excerpt(100); ?></div>
									</div>
								</div>
							<?php endwhile; ?>

							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
								<?php echo get_next_posts_link("Lihat Lainnya", $my_query->max_num_pages); ?>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>