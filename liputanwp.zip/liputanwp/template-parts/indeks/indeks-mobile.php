<div class="main">
	<div class="main-container">
		<div class="article-row">
			<?php $class = "";
			$cat = $_GET['category'];
			$date = $_GET['date'];
			?>
			<div class="article kanal-box">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="indeks-data">
							<div class="subcategory">
								<select name="category" id="startCategory">
									<option <?php selected( $cat, "all" ); ?> value="all">Semua Kategori</option>
								<?php 
								foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
									?>
										<option <?php selected( $cat, $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
									<?php
								}
								?>
								</select>
							</div>
							<div id="boxDate">
								<input type="text" class="form-control" id="startDate" value="<?php echo $date; ?>" placeholder="Tanggal" disabled>
							</div>
							<div class="btn-form-indeks mobile">Lihat</div>
						</div>
						<h1 class="indeks-title"><?php the_title(); ?></h1>
						<div class="latest-area" data-indeks="<?php echo get_permalink(); ?>">
						<?php 
						$cat = $_GET['category'];
						$date = $_GET['date'];
						$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
						if($cat == "" && $date == "" || $cat == "all" && $date == ""){
							$args = array(
								'post_type' => 'post',
								'post_status' => 'publish',
								'paged' => $paged
							);
						}else if($cat != "" && $date == ""){
							$args = array(
								'category_name' => $cat,
								'post_type' => 'post',
								'post_status' => 'publish',
								'paged' => $paged
							);

						}else if($cat != "" && $date != ""){
							$timestart = strtotime($date);
							$timeend = strtotime($date . ' + 1 days');
							$start = date('d-m-Y',$timestart);
							$end = date('d-m-Y',$timeend);
							if($cat == "all"){
								$args = array(
									'post_type' => 'post',
									'post_status' => 'publish',
									'paged' => $paged,
									'date_query' => array(
										array(
						                    'after'     => $start,
						                    'before'    => $end,
										),
									),
								);
							}else{
								$args = array(
									'category_name' => $cat,
									'post_type' => 'post',
									'post_status' => 'publish',
									'paged' => $paged,
									'date_query' => array(
										array(
						                    'after'     => $start,
						                    'before'    => $end,
										),
									),
								);
							}
						}?>
						<?php 
						$my_query = new WP_Query( $args );
						if ( $my_query->have_posts() ):
							while ( $my_query->have_posts() ) :
								$my_query->the_post(); 
			                    $counter = get_post_meta( get_the_ID(), 'counter', true );?>
								<div class="article-item table">
									<div class="article-text">
										<div class="article-time">
											<?php if(!empty(labelcategory())): ?>
												<span class="article-category"><?php echo labelcategory(); ?></span>
											<?php endif; ?>
											<?php echo timeago(); ?>
										</div>
										<h2 class="article-title">
											<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
										</h2>
									</div>
									<div class="article-image media-image">
										<?php echo customthumbnail($post->ID, "thumbnail"); ?>
										<?php if(!empty($counter["foto"])): ?>
										<div class="foto-counter"><?php echo $counter["foto"]; ?></div>
										<?php endif; ?>
										<?php if(!empty($counter["video"])): ?>
										<div class="video-time"><?php echo $counter["video"]; ?></div>
										<?php endif; ?>
									</div>
								</div>
							<?php endwhile; ?>

							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
								<?php echo get_next_posts_link("Lihat Lainnya", $my_query->max_num_pages); ?>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>