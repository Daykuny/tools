<?php 
if (is_active_sidebar('breaking_area')) :
	dynamic_sidebar('breaking_area');
endif;
if (is_active_sidebar('billboard_area')) :?>
<div class="billboard">
<?php dynamic_sidebar('billboard_area');?>
</div>
<?php endif;?>
<div class="main">
	<div class="main-container">
		<div class="article-row">
			<div class="article">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="latest-area">
							<?php 
							if (is_active_sidebar('category_area')) :
								dynamic_sidebar('category_area');
							endif;
							?>
							<?php 
							$num = 1;
							if (have_posts()): ?>
								<?php 
								$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
								while (have_posts()): the_post(); 
	                    			$counter = get_post_meta( $post->ID, 'counter', true ); 
									$no = $num++;
									if(1 == $paged) {
										if($no == 1): ?>
											<div class="widget headline">
										<div class="headline-big">
											<div class="headline-box">
												<div class="headline-image media-image">
													<?php echo customthumbnail($post->ID, "image_640_360"); ?>
												</div>
												<div class="headline-text">
													<div class="headline-time">
														<?php echo timeago(); ?>
													</div>
														<h2 class="headline-title">
														<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
														</h2>
													</div>
												</div>
											</div>
											</div>
										<?php else: ?>
										<div class="article-item table">
											<div class="article-text">
												<div class="article-time">
													<?php if(!empty(labelcategory())): ?>
														<span class="article-category"><?php echo labelcategory(); ?></span>
													<?php endif; ?>
													<?php echo timeago(); ?>
												</div>
												<h2 class="article-title">
													<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
												</h2>
											</div>
											<div class="article-image media-image">
												<?php echo customthumbnail($post->ID, "thumbnail"); ?>
												<?php if(!empty($counter["foto"])): ?>
												<div class="foto-counter"><?php echo $counter["foto"]; ?></div>
												<?php endif; ?>
												<?php if(!empty($counter["video"])): ?>
												<div class="video-time"><?php echo $counter["video"]; ?></div>
												<?php endif; ?>
											</div>
										</div>
										<?php endif ?>
									<?php }else{ ?>
										<div class="article-item table">
											<div class="article-text">
												<div class="article-time">
													<?php if(!empty(labelcategory())): ?>
														<span class="article-category"><?php echo labelcategory(); ?></span>
													<?php endif; ?>
													<?php echo timeago(); ?>
												</div>
												<h2 class="article-title">
													<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
												</h2>
											</div>
											<div class="article-image media-image">
												<?php echo customthumbnail($post->ID, "thumbnail"); ?>
												<?php if(!empty($counter["foto"])): ?>
												<div class="foto-counter"><?php echo $counter["foto"]; ?></div>
												<?php endif; ?>
												<?php if(!empty($counter["video"])): ?>
												<div class="video-time"><?php echo $counter["video"]; ?></div>
												<?php endif; ?>

											</div>
										</div>
									<?php } ?>
								<?php endwhile; ?>
							<?php endif; ?>
							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
						<?php echo get_next_posts_link("Lihat Lainnya <i class='icon icon-arrow-right'></i>"); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php get_template_part("template-parts/sidebar/index"); ?>
		</div>
	</div>
</div>