<?php 
if (is_active_sidebar('breaking_area')) :
	dynamic_sidebar('breaking_area');
endif;
if (is_active_sidebar('billboard_area')) : ?>
<div class="billboard">
	<?php dynamic_sidebar('billboard_area');?>
</div>
<?php endif; ?>
<div class="main">
	<div class="main-container">
		<div class="article-row">
			<div class="article">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="latest-area">
							<?php 
							if (is_active_sidebar('category_area')) :
								dynamic_sidebar('category_area');
							endif;
							?>
							<?php 
							$num = 1;
							if (have_posts()): ?>
								<?php 
								$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
								while (have_posts()): the_post(); 
           							$counter = get_post_meta( get_the_ID(), 'counter', true );
									$no = $num++;
									if(1 == $paged) {
										if($no == 1):
										?>
										<div class="widget headline">
										<div class="headline-big">
											<div class="headline-box">
												<div class="headline-image media-image"><?php echo customthumbnail(get_the_ID(), "image_640_360"); ?></div>
												<div class="headline-text">
													<div class="headline-time">
														<?php if ( has_post_format(array('image', 'gallery'))): ?>
															<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><path d="M2 5.413h3.547L6.946 2h7.832l1.4 3.413h3.546v11.82H2z"/><path stroke="currentColor" d="M10.862 7.378a2.795 2.795 0 0 1 2.788 2.8 2.795 2.795 0 0 1-2.788 2.802 2.795 2.795 0 0 1-2.788-2.801 2.795 2.795 0 0 1 2.788-2.801zm0-1.965c2.62 0 4.744 2.134 4.744 4.766 0 2.631-2.124 4.765-4.744 4.765-2.62 0-4.744-2.134-4.744-4.765 0-2.632 2.124-4.766 4.744-4.766z"/><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M2 5.413h3.547L6.946 2h7.832l1.4 3.413h3.546v11.82H2z"/></g></svg>
														<?php elseif ( has_post_format('video') ): ?>
															<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><path fill="currentColor" d="M8.262 15.526a.368.368 0 0 1-.369-.368v-8.35a.368.368 0 0 1 .553-.319l7.23 4.175a.368.368 0 0 1 0 .638l-7.23 4.174a.368.368 0 0 1-.184.05zm.368-8.08v7.074l6.126-3.537L8.63 7.446z"/><path fill="currentColor" d="M10.983 19.966c-2.4 0-4.655-.935-6.352-2.631A8.924 8.924 0 0 1 2 10.983c0-2.4.934-4.655 2.631-6.352A8.924 8.924 0 0 1 10.983 2c2.4 0 4.655.934 6.352 2.631a8.924 8.924 0 0 1 2.63 6.352c0 2.4-.934 4.655-2.63 6.352a8.924 8.924 0 0 1-6.352 2.63zm0-17.23a8.193 8.193 0 0 0-5.831 2.416 8.193 8.193 0 0 0-2.416 5.831 8.19 8.19 0 0 0 2.416 5.831 8.193 8.193 0 0 0 5.83 2.416 8.193 8.193 0 0 0 5.832-2.416 8.193 8.193 0 0 0 2.416-5.831 8.193 8.193 0 0 0-2.416-5.831 8.193 8.193 0 0 0-5.831-2.416z"/><path d="M0 0h22v22H0z"/></g></svg> 
														<?php endif; ?>
														<?php echo timeago(); ?>
													</div>
													<h2 class="headline-title">
														<a href="<?php echo  get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
													</h2>
													<div class="headline-content"><?php echo  get_excerpt(150); ?></div>
													</div>
												</div>
											</div>
											</div>
										<?php 
										else: ?>

										<div class="article-item table">
											<div class="article-image media-image">
												<?php echo customthumbnail($post->ID, "image_200_116"); ?>
											</div>
											<div class="article-text">
												<div class="article-time">
													<?php if(!empty(labelcategory())): ?>
														<span class="article-category"><?php echo labelcategory(); ?></span>
													<?php endif; ?>
													<?php echo timeago(); ?>
												</div>
												<h2 class="article-title">
													<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
												</h2>
												<div class="summary"><?php echo get_excerpt(100); ?></div>
											</div>
										</div>
										<?php
										endif;
									}else{
									?>
									<div class="article-item table">
										<div class="article-image media-image">
											<?php echo customthumbnail($post->ID, "image_200_116"); ?>
										</div>
										<div class="article-text">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
											<div class="summary"><?php echo get_excerpt(100); ?></div>
										</div>
									</div>
									<?php 
									}
									?>
								<?php endwhile; ?>
							<?php endif; ?>
							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
						<?php echo get_next_posts_link("Lihat Lainnya <i class='icon icon-arrow-right'></i>"); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php get_template_part("template-parts/sidebar/index"); ?>
		</div>
	</div>
</div>