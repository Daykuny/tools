<div class="tag-header">
	<div class="tag-wrapper">
		<div class="tag-title">
			<h1>#<?php echo single_tag_title(); ?></h1>
		</div>
		<?php 
		if($_GET['post_format'] == "gallery"){
			$classimage = "active";
		}elseif($_GET['post_format'] == "video"){
			$classvideo = "active";
		}else{
			$classall = "active";
		}
		?>
		<div class="tag-nav">
			<ul class="tag-nav-list">
				<li class="tags-item <?php echo $classall; ?>">
					<a class="tags-item-link" href="<?php echo get_tag_link(get_queried_object()->term_id);?>" data-label="All">Semua</a>
				</li>
				<li class="tags-item <?php echo $classvideo; ?>">
					<a class="tags-item-link" href="<?php echo get_tag_link(get_queried_object()->term_id);?>?post_format=video" data-label="Video">Video</a>
				</li>
				<li class="tags-item <?php echo $classimage; ?>">
					<a class="tags-item-link" href="<?php echo get_tag_link(get_queried_object()->term_id);?>?post_format=gallery" data-label="Photo">Foto</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="main">
	<div class="main-container">
		<div class="article-row">
			<?php get_template_part("template-parts/tag/tag-sidebar"); ?>
			<div class="article">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="latest-area">
							<?php 
							if($_GET['post_format'] == "gallery"){
								get_template_part("template-parts/tag/tag-image-desktop");
							}elseif($_GET['post_format'] == "video"){
								get_template_part("template-parts/tag/tag-video-desktop");
							}else{
								get_template_part("template-parts/tag/tag-all-desktop");
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>