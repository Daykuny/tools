<?php if(!$_GET['post_format']): ?>
<div class="sidebar">
	<div class="sidebar-box">
		<?php if(!empty(category_description())): ?>
		<div class="widget sidebar-desc"><?php echo category_description(); ?></div>
		<?php else: ?>
		<div class="widget sidebar-desc"><?php echo get_excerpt(100); ?></div>
		<?php endif; ?>
		<?php 
		$myfoto = new WP_Query( array(
			'tag_id' => get_queried_object()->term_id,
			'post_type' => 'post',
			'post_status' => 'publish',
            'posts_per_page'=> 2,
		    'tax_query' => array(
		        array(                
		            'taxonomy' => 'post_format',
		            'field' => 'slug',
		            'terms' => array( 
		                'post-format-gallery',
		            ),
		        )
		    )
		) );
		if ($myfoto->have_posts()):?>
			<div class="widget grid">
    			<div class="widget-header">
    				<h3 class="widget-title"><a href="?post_format=image">Foto <svg width="10" height="12" viewBox="0 0 10 12" xmlns="http://www.w3.org/2000/svg"><path d="M7.928 5.57L3.445 1.088a.306.306 0 0 0-.221-.096.305.305 0 0 0-.222.096l-.48.481a.305.305 0 0 0 0 .443l3.78 3.781-3.78 3.782a.305.305 0 0 0-.097.222c0 .083.032.156.096.221l.481.48a.304.304 0 0 0 .443 0l4.483-4.483a.304.304 0 0 0 0-.443z" fill="currentColor" fill-rule="evenodd"/></svg></a></h3>
    			</div>
    			<div class="widget-content">
    				<div class="sidebar-row">
						<?php
							while ($myfoto->have_posts()): $myfoto->the_post(); ?>
		    					<div class="sidebar-item column6">
			    					<div class="sidebar-image media-image">
										<?php echo customthumbnail($post->ID, "image_200_116"); ?>
			    					</div>
			    					<div class="sidebar-text">
			    						<h2 class="sidebar-title">
											<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
			    						</h2>
			    					</div>
		    					</div>
								<?php
							endwhile;
						?>
					</div>
				</div>
			</div>
		<?php
		endif;
		 ?>

		<?php 
		$myvideo = new WP_Query( array(
			'tag_id' => get_queried_object()->term_id,
			'post_type' => 'post',
			'post_status' => 'publish',
            'posts_per_page'=> 2,
		    'tax_query' => array(
		        array(                
		            'taxonomy' => 'post_format',
		            'field' => 'slug',
		            'terms' => array( 
		                'post-format-video',
		            ),
		        )
		    )
		) );
		if ($myvideo->have_posts()):?>
			<div class="widget grid">
    			<div class="widget-header">
    				<h3 class="widget-title"><a href="?post_format=video">Video <svg width="10" height="12" viewBox="0 0 10 12" xmlns="http://www.w3.org/2000/svg"><path d="M7.928 5.57L3.445 1.088a.306.306 0 0 0-.221-.096.305.305 0 0 0-.222.096l-.48.481a.305.305 0 0 0 0 .443l3.78 3.781-3.78 3.782a.305.305 0 0 0-.097.222c0 .083.032.156.096.221l.481.48a.304.304 0 0 0 .443 0l4.483-4.483a.304.304 0 0 0 0-.443z" fill="currentColor" fill-rule="evenodd"/></svg></a></h3>
    			</div>
    			<div class="widget-content">
    				<div class="sidebar-row">
						<?php
							while ($myvideo->have_posts()): $myvideo->the_post(); ?>
		    					<div class="sidebar-item column6">
			    					<div class="sidebar-image media-image">
										<?php echo customthumbnail($post->ID, "image_200_116"); ?>
			    					</div>
			    					<div class="sidebar-text">
			    						<h2 class="sidebar-title">
											<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
			    						</h2>
			    					</div>
		    					</div>
								<?php
							endwhile;
						?>
					</div>
				</div>
			</div>
		<?php
		endif;
		 ?>
	</div>
</div>
<?php endif; ?>