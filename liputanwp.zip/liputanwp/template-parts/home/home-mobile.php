<?php 
if (is_active_sidebar('breaking_area')) :
	dynamic_sidebar('breaking_area');
endif;
if (is_active_sidebar('billboard_area')) :?>
<div class="billboard">
<?php dynamic_sidebar('billboard_area');?>
</div>
<?php endif;?>
<div class="main">
	<div class="main-container">
		<div class="article-row">
			<div class="article">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="latest-area">
							<?php 
							if (is_active_sidebar('homepage_area')) :
								dynamic_sidebar('homepage_area');
							endif;
							?>
							<?php if (have_posts()): ?>
								<?php while (have_posts()): the_post(); ?>
									<?php if ( has_post_format(array('gallery'))):
	                    			$counter = get_post_meta( $post->ID, 'counter', true ); ?>
									<div class="article-item">
										<div class="article-video media-image">
											<?php echo customthumbnail($post->ID, "image_383_288"); ?>
											<?php if(!empty($counter["foto"])): ?>
											<div class="foto-counter"><?php echo $counter["foto"]; ?></div>
											<?php endif; ?>
										</div>
										<div class="article-text-video">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
									</div>
									<?php elseif ( has_post_format('video') ): 
	                    			$counter = get_post_meta( $post->ID, 'counter', true ); ?>
									<div class="article-item">
										<div class="article-video media-image">
											<?php echo customthumbnail($post->ID, "image_383_288"); ?>
											<?php if(!empty($counter["video"])): ?>
											<div class="video-time"><?php echo $counter["video"]; ?></div>
											<?php endif; ?>
										</div>
										<div class="article-text-video">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
									</div>
									<?php else: ?>
									<div class="article-item table">
										<div class="article-text">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
										<div class="article-image media-image">
											<?php echo customthumbnail($post->ID, "thumbnail"); ?>
										</div>
									</div>
									<?php endif; ?>
								<?php endwhile; ?>
							<?php endif; ?>
							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
						<?php echo get_next_posts_link("Lihat Lainnya <i class='icon icon-arrow-right'></i>"); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php get_template_part("template-parts/sidebar/index"); ?>
		</div>
	</div>
</div>