<?php 
if (is_active_sidebar('breaking_area')) :
	dynamic_sidebar('breaking_area');
endif;
if (is_active_sidebar('billboard_area')) :?>
<div class="billboard">
<?php dynamic_sidebar('billboard_area');?>
</div>
<?php endif;?>
<div class="main">
	<div class="main-container">
		<div class="article-row">
			<div class="article">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="latest-area">
							<?php 
							if (is_active_sidebar('homepage_area')) :
								dynamic_sidebar('homepage_area');
							endif;
							?>
							<?php if (have_posts()): ?>
								<?php while (have_posts()): the_post(); ?>
									<?php if ( has_post_format(array('gallery'))): 
									if ($gallery = get_post_gallery( get_the_ID(), false ) ) :
									$i = 1;
									$splittedgal = explode(",", $gallery['ids']);
									$arrgal = "'" . implode("', '", $splittedgal) ."'";
									$dataarr = "array(". $arrgal .")";
									$parsed = eval("return " . $dataarr . ";");
									?>
									<div class="article-item">
										<?php if(count($parsed) >= 3): ?>
										<div class="article-text-gallery">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
										<div class="article-gallery">
											<?php 
												$big = "";
												$small = '';
												$before = '<div class="gallery-box">';

													foreach ( $parsed as $id ) { 
													$no = $i++; 
													$count = count($parsed) - 3; 
													if($no <= 3):
														if ($no == 1):
															$big .= '<div class="big-gallery">' . wp_get_attachment_image($id, "image_383_288") . '</div>';
														endif;
														if ($no == 2):
															$small .= '<div class="small-gallery">' . wp_get_attachment_image($id, "image_255_143") . '</div>';
														endif;
														if ($no == 3):
															$small .= '<div class="small-gallery">' . wp_get_attachment_image($id, "image_255_143") . '<div class="counter"><span>' . $count . '+</span></div></div>';
														endif;
													endif;
													}
												$after = '</div>';
												echo $big . $before . $small . $after;
											    ?>
										</div>
										<?php else: ?>
										<div class="article-image media-image">
											<?php echo customthumbnail($post->ID, "image_200_116"); ?>
										</div>
										<div class="article-text">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
											<div class="summary"><?php echo get_excerpt(100); ?></div>
										</div>
										<?php endif; ?>
									</div>
									<?php endif; ?>
									<?php elseif ( has_post_format('video') ): 
	                    			$counter = get_post_meta( $post->ID, 'counter', true ); ?>
									<div class="article-item">
										<div class="article-text-video">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
										</div>
										<div class="article-video media-image">
											<?php echo customthumbnail($post->ID, "image_640_360"); ?>
											<?php if(!empty($counter["video"])): ?>
											<div class="video-time"><?php echo $counter["video"]; ?></div>
											<?php endif; ?>
											<div class="play-box">
												<i class="i-big-play-button"></i>
											</div>
										</div>
									</div>

									<?php else: ?>
									<div class="article-item table">
										<div class="article-image media-image">
											<?php echo customthumbnail($post->ID, "image_200_116"); ?>
										</div>
										<div class="article-text">
											<div class="article-time">
												<?php if(!empty(labelcategory())): ?>
													<span class="article-category"><?php echo labelcategory(); ?></span>
												<?php endif; ?>
												<?php echo timeago(); ?>
											</div>
											<h2 class="article-title">
												<a href="<?php echo get_permalink(); ?>" class="media-link"><?php echo get_the_title(); ?></a>
											</h2>
											<div class="summary"><?php echo get_excerpt(130); ?></div>
										</div>
									</div>
									<?php endif; ?>
								<?php endwhile; ?>
							<?php endif; ?>
							<div class="info">
								<button id="trigger1" class="trigger">Lihat Lainnya <i class='icon icon-arrow-right'></i></button>
								<div id="spinnerpost" class="loading">
									<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
								</div>
								<div class="no-more"><i class="tag-snippet__topic-icon i-checklist icon-nomore"></i> Sudah ditampilkan semua</div>
							</div>
							<div class="pagination">
						<?php echo get_next_posts_link("Lihat Lainnya <i class='icon icon-arrow-right'></i>"); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php get_template_part("template-parts/sidebar/index"); ?>
		</div>
	</div>
</div>