<?php 
if (is_active_sidebar('billboard_area')) :?>
<div class="billboard">
<?php dynamic_sidebar('billboard_area');?>
</div>
<?php endif;?>
<div class="main">
	<div class="main-container">
		<div class="article-row">
		<div class="article">
			<div class="article-wrapper">
				<div class="article-box">
					<div class="post-detail">
					    <div class="breadcrumbs">
					    	<ul>
					    		<li>
					    			<a href="<?php echo home_url(); ?>">Home</a>
					    		</li>
					    		<li>
					    			<svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12"><path d="M7.928 5.57L3.445 1.088a.306.306 0 0 0-.221-.096.305.305 0 0 0-.222.096l-.48.481a.305.305 0 0 0 0 .443l3.78 3.781-3.78 3.782a.305.305 0 0 0-.097.222c0 .083.032.156.096.221l.481.48a.304.304 0 0 0 .443 0l4.483-4.483a.304.304 0 0 0 0-.443z" fill="currentColor" fill-rule="evenodd"/></svg>
					    			<a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a>
					    		</li>
					    	</ul>
					    </div>
					    <?php 
						if (have_posts()):
						while (have_posts()): the_post();
						?>
					    <div class="post">
					    	<div class="post-header">
					    		<h1 class="post-title"><?php the_title(); ?></h1>
					    		<div class="grid-row">
						    		<div class="author author-box">
						    			<div class="author-text">
						    				<div class="author-inline">Oleh <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php echo get_the_author(); ?></a> pada</div>
											<div class="pub-time">
												<time class="time-publikasi"><?php echo get_the_date( get_option('date_format') ); ?> <?php echo get_the_time( get_option('time_format') ); ?>
													<button class="btn-modif" on="tap:AMP.setState({time: !time})" aria-label="Show Time"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><g fill="none" fill-rule="evenodd"><path d="M-418-284h1440v760H-418z"/><path d="M12 0v12H0V0z"/><path fill="currentColor" d="M2 4.334a.333.333 0 0 1 .588-.215L6 8.15l3.412-4.032a.333.333 0 1 1 .51.43L6.254 8.883a.335.335 0 0 1-.51 0L2.08 4.549A.334.334 0 0 1 2 4.334"/></g></svg></button>
												</time>
											</div>
						    			</div>
										<time class="time-modified" [class]="time ? 'time-modified show' : 'time-modified'"><span>Diperbarui</span> <?php echo get_the_modified_date( get_option('date_format') ); ?> <?php echo get_the_modified_time( get_option('time_format') ); ?>
										</time>
						    		</div>
					    		</div>
					    	</div>

							<?php if (!has_post_format( array( 'gallery', 'image', 'video' ) )): ?>
					    	<div class="post-featured">
								<?php if ( true == get_theme_mod( 'featuredimageactivepos', false )) : 
										if (has_post_thumbnail( get_the_ID() ) ): 
											?>
											<figure class="wp-block-image size-full">
												<div class="wp-image-box">
												<a data-fslightbox="gallery" href="<?php echo get_the_post_thumbnail_url($post_id,'full'); ?>" data-caption="<?php echo get_post(get_post_thumbnail_id())->post_excerpt ?>" data-thumb="<?php echo get_the_post_thumbnail_url($post_id,'thumbnail'); ?>">
													<?php 
													echo get_the_post_thumbnail( $post_id, 'full', array( 'class' => 'featured-image' ) );
													$caption = get_post(get_post_thumbnail_id())->post_excerpt;
													?>
													<div class="btn-viewbox">
														<button class="btn-biew">
															<i class="icon-expand"></i>
															<span class="text-view">Perbesar</span>
														</button>
													</div>
													</a>	
												</div>
											<?php 
												if(!empty($caption)){ ?>
													<figcaption><?php echo $caption; ?></figcaption>
											<?php } ?>
											</figure>
										<?php endif;
								endif;  ?>
					    	</div>
					    	<?php endif; ?>
				    		<div class="share nofixed">
				    			<div class="share-content">
								<?php  if ( true == get_theme_mod( 'tombolfacebook', true )) : ?>
					    			<a aria-label="facebook" href="https://web.facebook.com/sharer/sharer.php?u=<?php echo get_the_permalink(); ?>" class="btn-share facebook" target="_blank" rel="noopener"><i class="icon-share i-gallery-facebook"></i></a>
								<?php endif; ?>
								<?php  if ( true == get_theme_mod( 'tomboltwitter', true )) : ?>
					    			<a aria-label="twitter" href="https://twitter.com/intent/tweet?text=<?php echo get_the_permalink(); ?>" class="btn-share twitter" target="_blank" rel="noopener"><i class="icon-share i-gallery-twitter"></i></a>
								<?php endif; ?>
								<?php  if ( true == get_theme_mod( 'tombolemail', true )) : ?>
					    			<a aria-label="email" href="mailto:?to=&subject=<?php echo get_the_title(); ?>&body=<?php echo get_the_permalink(); ?>" class="btn-share email" target="_blank" rel="noopener"><i class="icon-share i-gallery-email"></i></a>
								<?php endif; ?>
								<?php  if ( true == get_theme_mod( 'tombolwhatsapp', true )) : ?>
					    			<a aria-label="whatsapp" href="https://api.whatsapp.com/send/?text=<?php echo get_the_permalink(); ?>" class="btn-share whatsapp" target="_blank" rel="noopener"><i class="icon-share i-gallery-whatsapp"></i></a>
								<?php endif; ?>
								<?php  if ( true == get_theme_mod( 'tombolcopylink', true )) : ?>
					    			<button aria-label="copylink" class="btn-share copylink" data-url="<?php echo get_the_permalink(); ?>">Copy Link</button>
								<?php endif; ?>
					    		</div>
				    		</div>
							<?php $tim = get_post_meta(get_the_ID(), 'tim', true ); ?>
					    	<div class="post-content">
					    		<?php echo apply_filters( 'the_content', $post->post_content ); ?>
					    	</div>
					    	<div class="post-footer">
					    	    <?php if(has_tag()): ?>
								<div class="tags">
									<h3 class="tags-title">Tag</h3>
									<?php 
										echo '<ul>';
										$ordered_tag_list = wp_get_post_terms(get_the_ID(), 'post_tag', array('orderby' => 'term_id', 'fields' => 'all'));
										foreach($ordered_tag_list as $tag) {
											if($tag->description !=""):
												$ver = '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><g fill="none" fill-rule="evenodd" stroke="currentColor" transform="translate(1 1)"><circle cx="5" cy="5" r="5"/><path d="M2.903 4.9l1.403 1.656 3.03-3.062"/></g></svg>';
											else:
												$ver = "";
											endif;
										    echo '<li><a href="' . get_term_link( $tag ) . '"><span>' . esc_html( $tag->name ) . '</span>'. $ver .'</a></li>'; 
										}
										echo '</ul>';
									 ?>
								</div>
								<?php endif; ?>
						    		<div class="credits">
						    			<div class="credits-label">
											<?php 
											if ( "" != (get_theme_mod( 'tombolredaksititle' ))) :
												echo get_theme_mod( 'tombolredaksititle' );
											else:
												echo 'Tim Redaksi';
											endif;
											?>
						    			</div>
						    			<div class="credits-content">
											<?php if ( true == get_theme_mod( 'timredaksipenulis', true )) : ?>
												<a aria-label="Author" href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>">
													<?php echo get_avatar( get_the_author_meta( 'ID' ), 40 ); ?>
												</a>
										    <?php endif;  ?>
											<?php if ( true == get_theme_mod( 'timredaksieditor', true )) : ?>
												<?php if(!empty($tim['editor']) && $tim['editor'] != "-1"): ?>
													<?php echo get_avatar( $tim['editor'], 40 ); ?>
												<?php endif; ?>
										    <?php endif;  ?>
											<?php if ( true == get_theme_mod( 'timredaksireporter', true )) : ?>
												<?php if(!empty($tim['reporter']) && $tim['reporter'] != "-1"): ?>
													<?php echo get_avatar( $tim['reporter'], 40 ); ?>
												<?php endif; ?>
										    <?php endif;  ?>
						    			</div>
						    		</div>
								<?php 
								if (is_active_sidebar('afterpos_area')) :
									dynamic_sidebar('afterpos_area');
								endif;
								if ( comments_open() || get_comments_number() ) :
									comments_template();
								endif;
								 ?>
					    	</div>
					    </div>
						<?php
						endwhile;
						endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php get_template_part("template-parts/sidebar/index"); ?>
		</div>
	</div>
</div>