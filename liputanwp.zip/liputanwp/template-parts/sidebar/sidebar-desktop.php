<aside class="sidebar">
	<?php
	if(is_home()):
		if (is_active_sidebar('sidebar_area')) :
			dynamic_sidebar('sidebar_area');
		endif;
	endif;
	if(is_single()):
		if (is_active_sidebar('sidebar_pos')) :
			dynamic_sidebar('sidebar_pos');
		endif;
	endif;
	if(is_author() || is_tag() || is_search() || is_category()):
		if (is_active_sidebar('sidebar_archive')) :
			dynamic_sidebar('sidebar_archive');
		endif;
	endif;
	?>
</aside>