<aside class="sidebar">
	<div class="sidebar-sticky">
	<?php 
	if (is_active_sidebar('sidebar_area')) :
		dynamic_sidebar('sidebar_area');
	endif;
	 ?>						
	</div>
</aside>