<div class="main">
	<div class="main-container">
		<div class="notfound-box">
			<div class="notfound-wrap">
				<img class="notfound-message-image" src="<?php echo get_stylesheet_directory_uri() . '/assets/img/icon-404.png'; ?>">
				<h2 class="notfound-message-caption">Halaman tidak ditemukan</h2>
				<p class="notfound-message-sub-caption">Alamat yang anda masukkan salah, tidak tersedia, atau sudah dihapus</p><a class="notfound-message-button" href="<?php echo get_home_url(); ?>">Home</a></div>
			</div>
		</div>
	</div>
</div>