<div class="main">
	<div class="main-container">
		<div class="article-row">
				<?php $class = "";
				$cat = $_GET['category'];
				$date = $_GET['date'];
				?>
			<div class="article kanal-box">
				<div class="article-wrapper">
					<div class="article-box">
						<div class="indeks-data">
							<div class="subcategory">
								<select name="category" id="startCategory">
									<option <?php selected( $cat, "all" ); ?> value="all">Semua Kategori</option>
								<?php 
								foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
									?>
										<option <?php selected( $cat, $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
									<?php
								}
								?>
								</select>
							</div>
							<div class="btn-form-indeks mobile">Lihat</div>
						</div>
						<h1 class="indeks-title"><?php the_title(); ?></h1>
						<div class="latest-area" data-indeks="<?php echo get_permalink(); ?>">
						<?php the_content(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>