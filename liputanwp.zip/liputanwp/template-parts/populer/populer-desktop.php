<div class="main">
	<div class="main-container">
		<div class="article-row">
				<?php $class = "";
				$cat = $_GET['category'];
				$date = $_GET['date'];
				?>
			<div class="sidebar kanal-box">
				<div class="kanal-menu">
					<div class="kanal-header">
						<div class="kanal-title">Kategori</div>
					</div>
					<div class="kanal-body">
						<ul>
							<li class="<?php if ($cat == "" || $cat == "all"){echo "current-menu-item";}?>"><a href="?category=all">Semua Kategori <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg></a></li>
						<?php foreach(get_terms('category','parent=0&hide_empty=true') as $term) { ?>
							<li class="<?php if ($cat==$term->slug){echo "current-menu-item";}?>"><a href="?category=<?php echo $term->slug; ?>"><?php echo $term->name; ?> <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg></a></li>
						<?php } ?>
						</ul>
					</div>
				</div>
			</div>
			<div class="article kanal-box">
				<div class="article-wrapper">
					<div class="article-box">
						<h1 class="indeks-title"><?php the_title(); ?></h1>
						<div class="latest-area" data-indeks="<?php echo get_permalink(); ?>">
						<?php the_content(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>