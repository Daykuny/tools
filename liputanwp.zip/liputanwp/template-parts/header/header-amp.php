<?php 
if (is_active_sidebar('parallax_mobile')) : ?>
<div class="billboard parallax" [class]="parallax ? 'billboard parallax hide' : 'billboard parallax'">
	<?php dynamic_sidebar('parallax_mobile'); ?>	
</div>
<?php 
endif;
?>
<header [class]="header ? 'header ontop' : 'header'" class="header">
	<div class="header-box">
		<div class="header-left">
			<button class="bar" on="tap:AMP.setState({sidebarmenu: !sidebarmenu})" aria-label="Menu">
				<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50"><g fill="none" fill-rule="evenodd"><path d="M0 0h50v50H0z"/><path d="M28.75 23a1.25 1.25 0 0 1 0 2.5h-17.5a1.25 1.25 0 0 1 0-2.5h17.5zm0-6a1.25 1.25 0 0 1 0 2.5h-17.5a1.25 1.25 0 1 1 0-2.5h17.5zm-6-6a1.25 1.25 0 0 1 0 2.5h-11.5a1.25 1.25 0 1 1 0-2.5h11.5z" fill="currentColor"/></g></svg></button>
		</div>
		<div class="header-brand">
			<?php 
				if (function_exists('the_custom_logo')) :
					if(has_custom_logo()) :
						echo the_custom_logo();
					endif;
				endif;
				$blogInfo = get_bloginfo('name');
				if (!empty($blogInfo)) : 
					if (is_front_page() && is_home()) :
						brand_h1();
						else :
						brand_p();
					endif;
				endif;
				$description = get_bloginfo( 'description', 'display' );
				if ($description || is_customize_preview()) :
					brand_description($description);
				endif;
			?>
		</div>
		<div class="header-right">
		<button class="icon-search" aria-label="search" on="tap:AMP.setState({search: !search, header: !header, parallax: !parallax})"></button>
		<button class="mode icon-darkmode" aria-label="dark mode" on="tap:AMP.setState({darkmode: !darkmode})"></button>
		</div>
	</div>
</header>
<div class="header-search" [class]="search ? 'header-search show' : 'header-search'">
	<form class="header-search-form" method="get" action="<?php echo home_url('/'); ?>">
		<div class="header-search-wrapper">
			<input  class="header-input-search" type="text" name="s" placeholder="berita apa yang ingin anda baca hari ini?" value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
			<input type="hidden" name="post_type" value="post" />
		</div>
	</form>
</div>
<div class="search-transparent" [class]="search ? 'search-transparent show' : 'search-transparent'" on="tap:AMP.setState({search: !search, header: !header, parallax: !parallax})"></div>
<div [class]="sidebarmenu ? 'sidebar-menu show' : 'sidebar-menu'" class="sidebar-menu">
	<div class="sidebar-menu-header">
		<div class="sidebar-menu-title">Menu</div>
		<button class="icon-close" aria-label="close" on="tap:AMP.setState({sidebarmenu: !sidebarmenu})">
			<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><path id="a" d="M0 0h32v32H0z"/></defs><g fill="none" fill-rule="evenodd"><g opacity=".2" fill-opacity="0" fill="#F00"><use xlink:href="#a"/><use xlink:href="#a"/></g><path d="M16 14.72L9.28 8 7.866 9.414l6.72 6.72L7.87 22.85l1.414 1.414L16 17.548l6.715 6.715 1.414-1.414-6.715-6.715 6.72-6.72L22.72 8 16 14.72z" fill="currentColor"/></g></svg></button>
	</div>
	<div class="sidebar-menu-content">
		<?php 
		if (is_active_sidebar('sidebar_menu')) :
			dynamic_sidebar('sidebar_menu');
		endif;
		 ?>
	</div>
</div>